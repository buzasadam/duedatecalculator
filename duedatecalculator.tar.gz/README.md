Author: Buzás Ádám

Emarsys Software developer homework - Due Date Calculator

phpunit timezone must be configured to run test correctly
phpunit -d date.timezone=Europe/Budapest tests
