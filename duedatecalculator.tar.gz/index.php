<?php

require_once __DIR__ . '/vendor/autoload.php';


use App\DateCalculator;

// Jelenlegi időpont és időzóna beállítás
$date = new DateTime();
$date->setTimezone(new DateTimeZone('Europe/Budapest'));

// Válaszadási határidő
$turnaround = 5;

$dc = new DateCalculator;

// Eredmény
echo $date->format('Y-m-d H:i').'<br>';
echo 'Turnaround: '.$turnaround.' hour(s)<br>';
echo $dc->calculateDueDate($date,$turnaround);
